import PageModal from './src/page-modal.vue'

export default PageModal
