import StatisticalPanel from './src/statistical-panel.vue'

export default StatisticalPanel
