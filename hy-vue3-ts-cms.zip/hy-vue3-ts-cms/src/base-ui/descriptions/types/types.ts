export interface DescriptionProp {
  name: string
  description: string
}
