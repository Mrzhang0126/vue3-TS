import HyDescriptions from './src/descriptions.vue'
import type { DescriptionProp } from './types/types'

export { DescriptionProp }
export default HyDescriptions
