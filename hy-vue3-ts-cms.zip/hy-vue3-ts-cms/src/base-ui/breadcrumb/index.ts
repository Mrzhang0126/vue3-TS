import HyBreadcrumb from './src/breadcrumb.vue'

export default HyBreadcrumb
