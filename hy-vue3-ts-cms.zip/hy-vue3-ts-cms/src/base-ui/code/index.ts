import HyCode from './src/code.vue'
export default HyCode
